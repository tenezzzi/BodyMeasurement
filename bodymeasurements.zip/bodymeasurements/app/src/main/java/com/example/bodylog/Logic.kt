package com.example.bodylog

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.roundToInt
import kotlin.math.pow

val FIELDS = listOf(
    "height" to "Рост, см", "weight" to "Вес, кг", "neck" to "Шея, см",
    "shoulders" to "Плечи (обхват), см", "chest" to "Грудь, см", "waist" to "Талия, см",
    "hip" to "Бёдра/ягодицы, см", "biceps" to "Бицепс, см", "thigh" to "Бедро, см", "calf" to "Голень, см",
    "forearm" to "Предплечье, см", "wrist" to "Запястье, см", "ankle" to "Лодыжка, см"
)

data class Entry(val t: Long, val v: Map<String, Double>)
data class Profile(val male: Boolean = true, val age: Int = 25, val act: Double = 1.55, val goal: Double = 0.0)

class Store(c: Context) {
    private val p = c.getSharedPreferences("bodylog", 0)

    fun entries(): List<Entry> {
        val a = JSONArray(p.getString("e", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it); val m = o.getJSONObject("v")
            Entry(o.getLong("t"), m.keys().asSequence().associateWith { k -> m.getDouble(k) })
        }
    }

    fun save(l: List<Entry>) = p.edit().putString("e",
        JSONArray(l.map { JSONObject().put("t", it.t).put("v", JSONObject(it.v)) }).toString()).apply()

    fun water(day: String) = p.getInt("w$day", 0)
    fun setWater(day: String, n: Int) = p.edit().putInt("w$day", n).apply()

    fun food(day: String): List<Pair<String, Double>> {
        val a = JSONArray(p.getString("f$day", "[]"))
        return (0 until a.length()).map { a.getJSONObject(it).let { o -> o.getString("n") to o.getDouble("g") } }
    }
    fun saveFood(day: String, l: List<Pair<String, Double>>) = p.edit().putString("f$day",
        JSONArray(l.map { JSONObject().put("n", it.first).put("g", it.second) }).toString()).apply()

    fun look() = listOf(p.getInt("sk", 0), p.getInt("cl", 0), p.getInt("bd", 1))
    fun saveLook(l: List<Int>) = p.edit().putInt("sk", l[0]).putInt("cl", l[1]).putInt("bd", l[2]).apply()

    fun profile() = Profile(p.getBoolean("m", true), p.getInt("a", 25), p.getFloat("act", 1.55f).toDouble(), p.getFloat("g", 0f).toDouble())
    fun saveProfile(x: Profile) = p.edit().putBoolean("m", x.male).putInt("a", x.age)
        .putFloat("act", x.act.toFloat()).putFloat("g", x.goal.toFloat()).apply()
}

class Metrics(e: Entry, pr: Profile) {
    val h = e.v["height"] ?: 0.0
    val w = e.v["weight"] ?: 0.0
    val bmi = if (h > 0) w / (h / 100).pow(2) else 0.0

    // Формула US Navy (обхваты в см)
    val fat: Double? = run {
        val wa = e.v["waist"]; val n = e.v["neck"]; val hi = e.v["hip"]
        if (h <= 0 || wa == null || n == null) null
        else if (pr.male) (wa - n).takeIf { it > 0 }?.let { 495 / (1.0324 - 0.19077 * log10(it) + 0.15456 * log10(h)) - 450 }
        else if (hi == null) null
        else (wa + hi - n).takeIf { it > 0 }?.let { 495 / (1.29579 - 0.35004 * log10(it) + 0.221 * log10(h)) - 450 }
    }
    val lean = fat?.let { w * (1 - it / 100) }
    val whr = e.v["waist"]?.let { wa -> e.v["hip"]?.let { wa / it } }
    val bmr = 10 * w + 6.25 * h - 5 * pr.age + if (pr.male) 5 else -161   // Миффлин–Сан Жеор
    val tdee = bmr * pr.act
    val ideal = (if (pr.male) 50.0 else 45.5) + 2.3 * (h / 2.54 - 60)       // Девайн
    val protein = w * 1.8
    val water = w * 0.035
}

fun bmiText(b: Double) = when {
    b < 18.5 -> "дефицит массы"; b < 25 -> "норма"; b < 30 -> "избыток массы"; else -> "ожирение"
}

fun Double.f(): String = "%.1f".format(this)

fun sizeFor(chest: Double?): String? = chest?.let {
    when { it < 86 -> "XS"; it < 94 -> "S"; it < 102 -> "M"; it < 110 -> "L"; it < 118 -> "XL"; else -> "XXL" }
}

fun whrRisk(r: Double, male: Boolean) = if (r >= (if (male) 0.90 else 0.85)) "повышенный" else "в норме"

/** Линейный прогноз по первому и последнему замеру веса. */
fun forecast(l: List<Entry>, goal: Double): String? {
    val a = l.firstOrNull { it.v["weight"] != null } ?: return null
    val b = l.last { it.v["weight"] != null }
    val days = (b.t - a.t) / 86_400_000.0
    if (goal <= 0 || days < 1) return null
    val perWeek = (b.v["weight"]!! - a.v["weight"]!!) / days * 7
    val need = goal - b.v["weight"]!!
    if (abs(need) < 0.1) return "цель достигнута"
    if (perWeek == 0.0 || need / perWeek <= 0) return "тренд (${perWeek.f()} кг/нед) не ведёт к цели"
    return "≈ ${(need / perWeek).roundToInt()} нед. (${perWeek.f()} кг/нед)"
}

class Food(val n: String, val k: Double, val p: Double, val f: Double, val c: Double)

/** Название;ккал;белки;жиры;углеводы — на 100 г (средние справочные значения). */
private const val RAW = """Куриная грудка сырая;113;23.6;1.9;0.4
Куриная грудка варёная;137;29.8;1.8;0.5
Индейка филе;115;21.6;2.3;0
Говядина постная;187;18.9;12.4;0
Свинина постная;145;21;6;0
Яйцо куриное;157;12.7;11.5;0.7
Яичный белок;48;11;0.2;1
Лосось;208;20;13;0
Тунец консервированный;96;21;1;0
Треска;75;16;0.7;0
Креветки;87;18;1;0
Творог 5%;121;17;5;1.8
Творог обезжиренный;71;16.5;0.2;1.3
Греческий йогурт 2%;73;10;2;3.9
Кефир 1%;40;3;1;4
Молоко 2.5%;52;2.8;2.5;4.7
Сыр твёрдый;360;24;29;0
Протеин сывороточный (порошок);390;80;6;6
Рис варёный;130;2.7;0.3;28
Рис сухой;344;6.7;0.7;78.9
Гречка варёная;110;4.2;1.1;21.3
Гречка сухая;313;12.6;3.3;62.1
Овсянка сухая;352;12.3;6.2;61.8
Макароны варёные;158;5.8;0.9;30.9
Картофель варёный;86;1.7;0.4;20
Хлеб ржаной;214;6.6;1.2;40.9
Хлеб белый;265;9;3.2;49
Банан;96;1.5;0.2;21
Яблоко;47;0.4;0.4;9.8
Апельсин;43;0.9;0.2;8.1
Огурец;15;0.8;0.1;2.8
Помидор;20;1.1;0.2;3.7
Брокколи;34;2.8;0.4;6.6
Морковь;35;1.3;0.1;6.9
Авокадо;160;2;14.7;8.5
Арахисовая паста;588;25;50;20
Миндаль;579;21;50;22
Оливковое масло;884;0;100;0
Мёд;304;0.8;0;81.5
Чечевица варёная;116;9;0.4;20
Нут варёный;164;8.9;2.6;27
Тофу;76;8;4.8;1.9
Тёмный шоколад;546;6;35;48
Сахар;399;0;0;99.8"""

val FOODS: List<Food> = RAW.lines().map { l -> l.split(';').let { Food(it[0], it[1].toDouble(), it[2].toDouble(), it[3].toDouble(), it[4].toDouble()) } }

class Targets(val k: Double, val p: Double, val f: Double, val c: Double)

/** Суточная цель: норма ±по цели веса; белок 1.8 г/кг, жиры 25% калорий, остальное — углеводы. */
fun targets(m: Metrics, pr: Profile): Targets {
    val k = m.tdee * when { pr.goal > 0 && pr.goal < m.w - 0.5 -> .85; pr.goal > m.w + 0.5 -> 1.1; else -> 1.0 }
    val f = k * .25 / 9
    return Targets(k, m.protein, f, (k - m.protein * 4 - f * 9) / 4)
}