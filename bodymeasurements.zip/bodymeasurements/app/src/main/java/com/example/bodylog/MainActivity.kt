package com.example.bodylog

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import android.graphics.Bitmap
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.nativeCanvas
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val st = Store(this)
        setContent { AppTheme { App(st) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(st: Store) {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf(st.entries()) }
    var pr by remember { mutableStateOf(st.profile()) }
    var tab by remember { mutableIntStateOf(0) }
    val last = list.lastOrNull()
    val df = remember { SimpleDateFormat("dd.MM.yy", Locale.getDefault()) }
    fun upd(p: Profile) { pr = p; st.saveProfile(p) }
    var look by remember { mutableStateOf(st.look()) }
    fun setLook(i: Int, x: Int) { look = look.toMutableList().also { it[i] = x }; st.saveLook(look) }

    Box(Modifier.fillMaxSize().background(BG)) {
        Scaffold(containerColor = Color.Transparent, contentColor = Color.White, bottomBar = {
            NavigationBar(containerColor = Color(0xFF12162B)) {
                listOf("📏" to "Замер", "🧍" to "3D", "📈" to "Динамика", "🧮" to "Анализ", "🍽" to "Питание").forEachIndexed { i, (ic, t) ->
                    NavigationBarItem(tab == i, { tab = i }, { Text(ic) }, label = { Text(t) })
                }
            }
        }) { pad ->
            Column(Modifier.padding(pad).padding(12.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when (tab) {
                    0 -> {
                        val tx = remember(last) { mutableStateMapOf<String, String>().apply { last?.v?.forEach { (k, v) -> put(k, v.toString()) } } }
                        Text("Новый замер", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                        Text("Заполните, что знаете: модель и расчёты подстроятся", color = Color.White)
                        FIELDS.forEach { (k, n) ->
                            OutlinedTextField(tx[k] ?: "", { tx[k] = it }, label = { Text(n) }, singleLine = true, shape = RoundedCornerShape(16.dp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                        }
                        Button({
                            val m = tx.mapNotNull { (k, v) -> v.replace(',', '.').toDoubleOrNull()?.let { k to it } }.toMap()
                            if ("height" in m && "weight" in m) { list = list + Entry(System.currentTimeMillis(), m); st.save(list) }
                        }, Modifier.fillMaxWidth()) { Text("Сохранить замер (нужны рост и вес)") }
                    }
                    1 -> {
                        var rot by remember { mutableFloatStateOf(0f) }
                        var simH by remember(last) { mutableFloatStateOf((last?.v?.get("height") ?: 175.0).toFloat()) }
                        var simW by remember(last) { mutableFloatStateOf((last?.v?.get("weight") ?: 70.0).toFloat()) }
                        val base = last?.v ?: emptyMap()
                        val h0 = base["height"] ?: simH.toDouble(); val w0 = base["weight"] ?: simW.toDouble()
                        val L = simH / h0
                        val k = L * sqrt(simW / (w0 * L.pow(3)))   // масштаб обхватов при смене роста/веса
                        val v = base.mapValues { it.value * k } + mapOf("height" to simH.toDouble(), "weight" to simW.toDouble())
                        var cmp by remember { mutableIntStateOf(-1) }
                        Text("3D-модель (тяните пальцем, чтобы вращать)", style = MaterialTheme.typography.titleMedium)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(cmp < 0, { cmp = -1 }, { Text("Модель") })
                            list.forEachIndexed { i, e -> FilterChip(cmp == i, { cmp = i }, { Text("vs " + df.format(Date(e.t))) }) }
                        }
                        if (cmp in list.indices) Text("🔴 объём вырос, 🔵 уменьшился относительно выбранной даты", style = MaterialTheme.typography.bodySmall)
                        Body3D(v, rot, ref = list.getOrNull(cmp)?.v, female = false, skin = SKINS[look[0]], cloth = CLOTHS[look[1]], build = look[2], mod = Modifier.fillMaxWidth().height(420.dp).clip(RoundedCornerShape(28.dp)).background(Brush.radialGradient(listOf(Color(0xFF34307A), Color(0xFF10132B)))).pointerInput(Unit) {
                            detectDragGestures { _, d -> rot += d.x / 150f }
                        })
                        Text("Кастомизация", style = MaterialTheme.typography.titleSmall)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Худощавая", "Обычная", "Атлетичная", "Полная").forEachIndexed { i, n -> FilterChip(look[2] == i, { setLook(2, i) }, { Text(n) }) }
                        }
                        Text("Цвет кожи"); Swatch(SKINS, look[0]) { setLook(0, it) }
                        Text("Цвет одежды"); Swatch(CLOTHS, look[1]) { setLook(1, it) }
                        Text("Линейка слева — рост в см. «Фигура» — визуальная стилизация поверх замеров.", style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Tile("Рост, см", "${simH.roundToInt()}", ACC2, Modifier.weight(1f))
                            Tile("Вес, кг", "${simW.roundToInt()}", ACC, Modifier.weight(1f))
                            Tile("ИМТ", (simW / (simH / 100).pow(2)).toDouble().f(), ORG, Modifier.weight(1f))
                        }
                        Slider(simH, { simH = it }, valueRange = 140f..210f)
                        Slider(simW, { simW = it }, valueRange = 40f..160f)
                        if (pr.goal > 0) Button({ simW = pr.goal.toFloat() }) { Text("Показать меня с целевым весом") }
                        Text("Модель примерная: обхваты масштабируются от последнего замера.", style = MaterialTheme.typography.bodySmall)
                    }
                    2 -> {
                        var key by remember { mutableStateOf("weight") }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FIELDS.forEach { (k, n) -> FilterChip(key == k, { key = k }, { Text(n.substringBefore(",")) }) }
                        }
                        val pts = list.mapNotNull { it.v[key] }
                        Chart(pts, Modifier.fillMaxWidth().height(200.dp))
                        if (pts.size > 1) Text("Изменение: ${(pts.last() - pts.first()).f()}  (мин ${pts.min().f()}, макс ${pts.max().f()})")
                        Button({
                            val csv = "date," + FIELDS.joinToString(",") { it.first } + "\n" +
                                    list.joinToString("\n") { e -> df.format(Date(e.t)) + "," + FIELDS.joinToString(",") { e.v[it.first]?.toString() ?: "" } }
                            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/csv").putExtra(Intent.EXTRA_TEXT, csv), "Экспорт CSV"))
                        }) { Text("Экспорт CSV") }
                        list.reversed().forEach { e ->
                            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                                Text("${df.format(Date(e.t))}: ${e.v["weight"]?.f()} кг, талия ${e.v["waist"]?.f() ?: "—"}")
                                TextButton({ list = list - e; st.save(list) }) { Text("✕") }
                            }
                        }
                    }
                    3 -> {
                        Panel("Профиль и цель") {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                FilterChip(pr.male, { upd(pr.copy(male = true)) }, { Text("Муж") })
                                FilterChip(!pr.male, { upd(pr.copy(male = false)) }, { Text("Жен") })
                            }
                            Text("Возраст: ${pr.age}")
                            Slider(pr.age.toFloat(), { upd(pr.copy(age = it.roundToInt())) }, valueRange = 14f..80f)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(1.2 to "Сидячий", 1.375 to "Лёгкая", 1.55 to "Средняя", 1.725 to "Высокая", 1.9 to "Атлет")
                                    .forEach { (a, n) -> FilterChip(pr.act == a, { upd(pr.copy(act = a)) }, { Text(n) }) }
                            }
                            Text("Целевой вес: ${if (pr.goal > 0) pr.goal.roundToInt().toString() + " кг" else "не задан"}")
                            Slider(pr.goal.toFloat(), { upd(pr.copy(goal = it.toDouble())) }, valueRange = 0f..150f)
                        }
                        if (last == null) Text("Добавьте первый замер") else {
                            val m = Metrics(last, pr)
                            val t = targets(m, pr)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Tile("ИМТ", m.bmi.f(), ACC2, Modifier.weight(1f))
                                Tile("Жир, %", m.fat?.f() ?: "—", ORG, Modifier.weight(1f))
                                Tile("Ккал/день", "${t.k.roundToInt()}", ACC, Modifier.weight(1f))
                            }
                            Panel("Норма на день (с учётом цели)") {
                                Line("Белки", "${t.p.roundToInt()} г")
                                Line("Жиры", "${t.f.roundToInt()} г")
                                Line("Углеводы", "${t.c.roundToInt()} г")
                                Text("Белок 1,8 г/кг, жиры 25% калорий, остальное — углеводы.", style = MaterialTheme.typography.bodySmall)
                            }
                            Panel("Показатели") {
                                Line("ИМТ", "${m.bmi.f()} (${bmiText(m.bmi)})")
                                m.fat?.let { Line("Жир (US Navy)", "${it.f()} %") }
                                m.lean?.let { Line("Сухая масса", "${it.f()} кг") }
                                m.whr?.let { Line("Талия/бёдра", "%.2f".format(it)) }
                                Line("Идеальный вес (Девайн)", "${m.ideal.f()} кг")
                                Line("Базовый обмен", "${m.bmr.roundToInt()} ккал")
                                Line("Норма калорий", "${m.tdee.roundToInt()} ккал")
                                Line("Сушка (−15%)", "${(m.tdee * .85).roundToInt()} ккал")
                                Line("Набор (+10%)", "${(m.tdee * 1.1).roundToInt()} ккал")
                                Line("Вода", "${m.water.f()} л/день")
                                if (pr.goal > 0) Line("До цели", "${(m.w - pr.goal).f()} кг")
                                forecast(list, pr.goal)?.let { Line("Прогноз цели", it) }
                                m.whr?.let { Line("Риск (талия/бёдра)", whrRisk(it, pr.male)) }
                                sizeFor(last.v["chest"])?.let { Line("Размер одежды (по груди)", it) }
                            }
                        }
                    }
                    else -> Nutrition(st, last, pr)
                }
            }
        }
    }
}

val BG = Brush.verticalGradient(listOf(Color(0xFF0B0E1A), Color(0xFF1B1245)))
val ACC = Color(0xFF8B6CFF); val ACC2 = Color(0xFF00E5C3); val ORG = Color(0xFFFFB74D); val PNK = Color(0xFFFF6B9A)

@Composable
fun AppTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = ACC, secondary = ACC2, background = Color(0xFF0B0E1A), surface = Color(0xFF151A30),
        surfaceVariant = Color(0xFF1E2440), onSurface = Color.White, onBackground = Color.White,
        onSurfaceVariant = Color.White, onPrimary = Color.White, primaryContainer = Color(0xFF3A2C8F)),
    shapes = Shapes(small = RoundedCornerShape(14.dp), medium = RoundedCornerShape(20.dp), large = RoundedCornerShape(28.dp)),
    content = content)

@Composable
fun Panel(title: String? = null, content: @Composable ColumnScope.() -> Unit) = Card(
    Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2040), contentColor = Color.White)) {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        title?.let { Text(it, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White) }
        content()
    }
}

@Composable
fun Tile(label: String, value: String, c: Color, mod: Modifier) =
    Column(mod.background(c.copy(alpha = .16f), RoundedCornerShape(20.dp)).padding(14.dp)) {
        Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = Color.White)
        Text(label, style = MaterialTheme.typography.bodySmall)
    }

@Composable
fun RingStat(p: Float, label: String, value: String, c: Color, mod: Modifier) =
    Column(mod, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(74.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize().padding(6.dp)) {
                drawArc(c.copy(alpha = .2f), 0f, 360f, false, style = Stroke(9.dp.toPx(), cap = StrokeCap.Round))
                drawArc(c, -90f, 360f * p.coerceIn(0f, 1f), false, style = Stroke(9.dp.toPx(), cap = StrokeCap.Round))
            }
            Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
        }
        Text(label, style = MaterialTheme.typography.labelSmall, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }

@Composable
fun Line(a: String, b: String) = Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
    Text(a, color = Color.White); Text(b, fontWeight = FontWeight.Bold)
}

@Composable
fun Chart(pts: List<Double>, mod: Modifier) {
    val c = MaterialTheme.colorScheme.secondary
    Canvas(mod) {
        if (pts.size < 2) return@Canvas
        val mn = pts.min(); val r = (pts.max() - mn).takeIf { it > 0 } ?: 1.0
        val path = Path()
        pts.forEachIndexed { i, p ->
            val x = size.width * i / (pts.size - 1); val y = (size.height * (1 - (p - mn) / r)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            drawCircle(c, 6f, Offset(x, y))
        }
        val fill = Path().apply { addPath(path); lineTo(size.width, size.height); lineTo(0f, size.height); close() }
        drawPath(fill, Brush.verticalGradient(listOf(c.copy(alpha = .35f), Color.Transparent)))
        drawPath(path, c, style = Stroke(5f, cap = StrokeCap.Round))
    }
}

val SKINS = listOf(0xFFF3D2B3, 0xFFE0AC69, 0xFFC68642, 0xFF8D5524, 0xFF5C3A21)
val CLOTHS = listOf(0xFF1E88E5, 0xFFE53935, 0xFF43A047, 0xFF212121, 0xFF8E24AA)

@Composable
fun Swatch(cs: List<Long>, sel: Int, on: (Int) -> Unit) = Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
    cs.forEachIndexed { i, c ->
        Box(Modifier.size(34.dp).background(Color(c), CircleShape)
            .border(3.dp, if (i == sel) Color.White else Color.Transparent, CircleShape).clickable { on(i) })
    }
}

private const val BW = 360
private const val BH = 560
private const val PPC = 2.35          // пикселей на см: фиксированный масштаб, поэтому рост виден
private const val FLOOR = BH - 14

private fun bm(bd: Int, k: String) = when (bd) {
    0 -> if (k == "neck" || k == "head") .98 else .94
    2 -> when (k) { "sh" -> 1.08; "chest" -> 1.06; "bi" -> 1.14; "fo" -> 1.06; "th" -> 1.06; "ca" -> 1.05; "waist" -> .96; else -> 1.0 }
    3 -> when (k) { "waist" -> 1.12; "hip" -> 1.06; "chest" -> 1.05; "th" -> 1.08; "bi" -> 1.05; else -> 1.0 }
    else -> 1.0
}

private fun dims(v: Map<String, Double>, f: Boolean, bd: Int): Map<String, Double> {
    val h = v["height"] ?: 175.0; val w = v["weight"] ?: 70.0
    val s = sqrt(w / (h / 100).pow(2) / 22.0)
    fun g(k: String, m: Double, fm: Double) = v[k] ?: (h * (if (f) fm else m) * s)
    return mapOf("hip" to g("hip", .54, .57), "waist" to g("waist", .45, .41), "chest" to g("chest", .55, .53),
        "sh" to g("shoulders", .64, .58), "neck" to g("neck", .2, .17), "bi" to g("biceps", .17, .15), "th" to g("thigh", .31, .34),
        "ca" to g("calf", .21, .2), "head" to h * (if (f) .31 else .32), "fo" to g("forearm", .15, .13),
        "wr" to g("wrist", .095, .085), "ank" to g("ankle", .13, .125)).mapValues { it.value * bm(bd, it.key) }
}

/** Уровень сечения: высота (доля роста), ключ обхвата, множитель, глубина/ширина, сдвиг вперёд (в радиусах). Списки — по возрастанию y. */
private class Lv(val y: Double, val k: String, val m: Double, val q: Double = 1.0, val zs: Double = 0.0)

private fun torso(f: Boolean): List<Lv> {
    val cq = if (f) .82 else .74; val wy = if (f) .6 else .62
    return listOf(Lv(.465, "hip", .92, .8), Lv(.5, "hip", 1.0, .8), Lv(.545, "hip", 1.0, .78), Lv(wy, "waist", 1.0, .72),
        Lv(.665, "waist", 1.05, .72), Lv(.7, "chest", 1.0, cq), Lv(.745, "chest", 1.02, cq), Lv(.78, "sh", .97, .52),
        Lv(.81, "sh", .82, .55), Lv(.838, "neck", 1.35, .8), Lv(.87, "neck", 1.1, .92), Lv(.9, "neck", 1.0, .95))
}
private val HEAD = listOf(Lv(.88, "neck", 1.0, .95), Lv(.9, "head", .74, .9), Lv(.915, "head", .88), Lv(.935, "head", .98, 1.1),
    Lv(.955, "head", 1.0, 1.12), Lv(.975, "head", .92, 1.1), Lv(.99, "head", .68, 1.05), Lv(1.0, "head", .25))
private val LEG = listOf(Lv(.0, "ank", 2.1, 2.6, 1.2), Lv(.015, "ank", 2.2, 2.6, 1.2), Lv(.04, "ank", 1.05, 1.0, .3), Lv(.09, "ca", .72),
    Lv(.15, "ca", .96), Lv(.21, "ca", 1.0), Lv(.26, "ca", .8), Lv(.285, "th", .66), Lv(.34, "th", .82), Lv(.4, "th", .97),
    Lv(.46, "th", 1.06), Lv(.52, "th", 1.08))
private val ARM = listOf(Lv(.35, "wr", .7, .4), Lv(.37, "wr", 1.45, .34), Lv(.4, "wr", 1.6, .34), Lv(.425, "wr", 1.2, .5),
    Lv(.445, "wr", 1.0, .9), Lv(.48, "fo", .78), Lv(.54, "fo", .98), Lv(.595, "fo", 1.0), Lv(.635, "bi", .88), Lv(.69, "bi", .98),
    Lv(.73, "bi", 1.05), Lv(.775, "bi", 1.12), Lv(.808, "bi", .95), Lv(.828, "bi", .55), Lv(.838, "bi", .25))

/** Поперечное сечение (эллипс) как гладкая функция высоты: сплайн Catmull-Rom по уровням. */
private class Col(val id: Int, val cx: Double, lv: List<Lv>, d: Map<String, Double>, h: Double) {
    val n = lv.size
    val ys = DoubleArray(n) { lv[it].y * h }
    val cs = DoubleArray(n) { d.getValue(lv[it].k) * lv[it].m }
    val qs = DoubleArray(n) { lv[it].q }
    val zs = DoubleArray(n) { lv[it].zs }
    var a = 1.0; var b = 1.0; var zc = 0.0; var slope = 0.0
    private fun cr(v: DoubleArray, i: Int, t: Double): Double {
        val p0 = v[max(i - 1, 0)]; val p1 = v[i]; val p2 = v[i + 1]; val p3 = v[min(i + 2, n - 1)]
        return .5 * (2 * p1 + (p2 - p0) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t + (3 * p1 - p0 - 3 * p2 + p3) * t * t * t)
    }
    private fun ev(y: Double) {
        var i = 0
        while (i < n - 2 && y > ys[i + 1]) i++
        val t = ((y - ys[i]) / (ys[i + 1] - ys[i])).coerceIn(0.0, 1.0)
        val r = cr(cs, i, t) / (2 * PI); val q = cr(qs, i, t)
        a = r * sqrt(2 / (1 + q * q)); b = a * q; zc = cr(zs, i, t) * r
    }
    fun at(y: Double): Boolean {
        if (y < ys[0] || y > ys[n - 1]) return false
        ev(min(y + 1, ys[n - 1])); val p = a + b; ev(max(y - 1, ys[0])); val m = a + b; ev(y)
        slope = (p - m) / 4; return true
    }
}

private fun makeCols(d: Map<String, Double>, h: Double, f: Boolean): List<Col> {
    val l = mutableListOf(Col(0, 0.0, torso(f), d, h), Col(1, 0.0, HEAD, d, h))
    for ((i, sg) in listOf(-1.0, 1.0).withIndex()) {
        l.add(Col(2 + i, sg * d.getValue("hip") / (2 * PI) * .67, LEG, d, h))   // ноги выходят из таза
        l.add(Col(4 + i, sg * d.getValue("sh") / (2 * PI) * 1.1, ARM, d, h))    // руки растут из плеч
    }
    return l
}

private fun rgb(c: Long) = doubleArrayOf(((c shr 16) and 255) / 255.0, ((c shr 8) and 255) / 255.0, (c and 255) / 255.0)

/** Трассировка лучей по сечениям: гладкая поверхность, освещение по нормалям, без граней. */
private fun render(px: IntArray, v: Map<String, Double>, rv: Map<String, Double>?, rot: Float, f: Boolean, skin: Long, cloth: Long, bd: Int) {
    java.util.Arrays.fill(px, 0)
    val h = v["height"] ?: 175.0; val rh = rv?.get("height") ?: h
    val cols = makeCols(dims(v, f, bd), h, f)
    val rcols = rv?.let { makeCols(dims(it, f, bd), rh, f) }
    val cr = cos(rot.toDouble()); val sr = sin(rot.toDouble())
    val sk = rgb(skin); val cl = rgb(cloth); val hair = doubleArrayOf(.16, .1, .07)
    val red = doubleArrayOf(.9, .2, .2); val blue = doubleArrayOf(.26, .65, .96); val gray = doubleArrayOf(.6, .6, .6)
    val on = BooleanArray(cols.size); val ratio = DoubleArray(cols.size)
    for (row in 0 until FLOOR) {
        val y = (FLOOR - row) / PPC
        var lo = 1e9; var hi = -1e9
        for (k in cols.indices) {
            val c = cols[k]; on[k] = c.at(y)
            if (!on[k]) continue
            val e = abs(c.cx) + c.a + c.b + abs(c.zc); lo = min(lo, -e); hi = max(hi, e)
            ratio[k] = if (rcols != null && rcols[k].at(y * rh / h)) (c.a + c.b) / (rcols[k].a + rcols[k].b) else 1.0
        }
        if (lo > hi) continue
        for (xp in max(0, (BW / 2 + lo * PPC).toInt() - 1)..min(BW - 1, (BW / 2 + hi * PPC).toInt() + 1)) {
            var rr = 0.0; var gg = 0.0; var bb = 0.0; var hits = 0
            for (sub in 0..1) {
                val X = (xp - BW / 2.0 + .25 + sub * .5) / PPC
                var best = -1e9; var bk = -1; var bgx = 0.0; var bgz = 0.0
                for (k in cols.indices) {
                    if (!on[k]) continue
                    val c = cols[k]
                    val u = X * cr - c.cx; val w = X * sr - c.zc
                    val ia = 1 / (c.a * c.a); val ib = 1 / (c.b * c.b)
                    val A = sr * sr * ia + cr * cr * ib; val B = 2 * (-u * sr * ia + w * cr * ib); val C = u * u * ia + w * w * ib - 1
                    val D = B * B - 4 * A * C
                    if (D < 0) continue
                    val s = (-B + sqrt(D)) / (2 * A)
                    if (s > best) { best = s; bk = k; bgx = (u - s * sr) * ia; bgz = (w + s * cr) * ib }
                }
                if (bk < 0) continue
                val c = cols[bk]
                val len = hypot(bgx, bgz); val hx = bgx / len; val hz = bgz / len           // нормаль в системе тела
                val sl = -c.slope; val nl = sqrt(1 + sl * sl)                                // наклон профиля даёт «рельеф»
                val nx = (hx * cr + hz * sr) / nl; val ny = sl / nl; val nz = (-hx * sr + hz * cr) / nl
                var base = sk
                if (rcols != null) base = if (ratio[bk] > 1.02) red else if (ratio[bk] < .98) blue else gray
                else when (c.id) {
                    0 -> if (y < .545 * h || (f && y > .625 * h && y < .735 * h)) base = cl
                    1 -> if (y > .955 * h || (y > .915 * h && hz < -.1)) base = hair
                    2, 3 -> if (y > (if (f) .33 else .3) * h) base = cl
                }
                val dif = max(0.0, -.45 * nx + .5 * ny + .74 * nz)
                val spec = .18 * max(0.0, -.241 * nx + .268 * ny + .933 * nz).pow(30)
                val rim = .12 * (1 - nz.coerceIn(0.0, 1.0)).pow(2)
                val lit = .3 + .75 * dif
                rr += min(1.0, base[0] * lit + spec + rim * base[0]); gg += min(1.0, base[1] * lit + spec + rim * base[1]); bb += min(1.0, base[2] * lit + spec + rim * base[2])
                hits++
            }
            if (hits > 0) px[row * BW + xp] = ((hits * 127).coerceAtMost(255) shl 24) or
                    ((rr / hits * 255).toInt() shl 16) or ((gg / hits * 255).toInt() shl 8) or (bb / hits * 255).toInt()
        }
    }
}

@Composable
fun Body3D(v: Map<String, Double>, rot: Float, mod: Modifier, ref: Map<String, Double>? = null,
           female: Boolean = false, skin: Long = SKINS[0], cloth: Long = CLOTHS[0], build: Int = 1) {
    val bmp = remember { Bitmap.createBitmap(BW, BH, Bitmap.Config.ARGB_8888) }
    val px = remember { IntArray(BW * BH) }
    Canvas(mod) {
        render(px, v, ref, rot, female, skin, cloth, build)
        bmp.setPixels(px, 0, BW, 0, 0, BW, BH)
        val s = size.height / BH; val dw = BW * s
        val fy = FLOOR * s
        drawOval(Color(0x55000000), Offset(size.width / 2 - 36 * PPC.toFloat() * s, fy - 5.dp.toPx()), androidx.compose.ui.geometry.Size(72 * PPC.toFloat() * s, 10.dp.toPx()))
        drawImage(bmp.asImageBitmap(), dstOffset = IntOffset(((size.width - dw) / 2).toInt(), 0),
            dstSize = IntSize(dw.toInt(), size.height.toInt()), filterQuality = FilterQuality.Medium)
        drawLine(Color.Gray, Offset(0f, fy), Offset(size.width, fy), 2f)
        val paint = android.graphics.Paint().apply { color = 0xFF9E9E9E.toInt(); textSize = 11.sp.toPx(); isAntiAlias = true }
        for (cm in 0..220 step 10) {
            val ty = (FLOOR - cm * PPC.toFloat()) * s; val long = cm % 50 == 0
            drawLine(Color.Gray, Offset(0f, ty), Offset(if (long) 18.dp.toPx() else 8.dp.toPx(), ty), 1.5f)
            if (long && cm > 0) drawContext.canvas.nativeCanvas.drawText("$cm", 22.dp.toPx(), ty + 4.dp.toPx(), paint)
        }
        ref?.get("height")?.let { rhh ->
            val ry = (FLOOR - rhh.toFloat() * PPC.toFloat()) * s
            drawLine(Color(0xAAFFFFFF), Offset(0f, ry), Offset(size.width, ry), 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))
        }
    }
}