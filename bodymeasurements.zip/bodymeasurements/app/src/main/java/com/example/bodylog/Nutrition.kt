package com.example.bodylog

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Nutrition(st: Store, last: Entry?, pr: Profile) {
    val day = remember { SimpleDateFormat("yyyyMMdd", Locale.US).format(Date()) }
    var sub by remember { mutableIntStateOf(0) }
    var log by remember { mutableStateOf(st.food(day)) }
    var water by remember { mutableIntStateOf(st.water(day)) }
    var q by remember { mutableStateOf("") }
    var sel by remember { mutableStateOf<Food?>(null) }
    var g by remember { mutableStateOf("100") }
    val m = last?.let { Metrics(it, pr) }
    val t = m?.let { targets(it, pr) }

    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(sub == 0, { sub = 0 }, { Text("Дневник") })
        FilterChip(sub == 1, { sub = 1 }, { Text("Советы") })
    }

    val tot = DoubleArray(4)
    log.forEach { (n, gr) -> FOODS.firstOrNull { it.n == n }?.let { f ->
        val x = gr / 100; tot[0] += f.k * x; tot[1] += f.p * x; tot[2] += f.f * x; tot[3] += f.c * x } }

    if (sub == 1) { Tips(); return }

    if (t == null) Text("Добавьте замер (рост и вес), чтобы рассчитать норму КБЖУ.")
    else Panel("Сегодня · осталось добрать") {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly) {
            listOf(Triple("Ккал", tot[0], t.k) to ACC, Triple("Белки", tot[1], t.p) to ACC2,
                Triple("Жиры", tot[2], t.f) to ORG, Triple("Углеводы", tot[3], t.c) to PNK).forEach { (x, c) ->
                val left = x.third - x.second
                RingStat((x.second / x.third).toFloat(), "${x.first}\nиз ${x.third.roundToInt()}",
                    if (left >= 0) "${left.roundToInt()}" else "+${(-left).roundToInt()}", c, Modifier)
            }
        }
        Text("В кольцах — сколько осталось съесть; со знаком + — перебор.", style = MaterialTheme.typography.bodySmall)
    }

    HorizontalDivider()
    Text("Добавить еду", style = MaterialTheme.typography.titleMedium)
    OutlinedTextField(q, { q = it }, label = { Text("Поиск продукта") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    if (q.isNotBlank()) FOODS.filter { it.n.contains(q, true) }.take(5).forEach {
        TextButton({ sel = it; q = "" }) { Text("${it.n} · ${it.k.roundToInt()} ккал") }
    }
    sel?.let { f ->
        Text("Выбрано: ${f.n} (на 100 г: ${f.k.roundToInt()} ккал, Б ${f.p.f()}, Ж ${f.f.f()}, У ${f.c.f()})")
        OutlinedTextField(g, { g = it }, label = { Text("Вес, г") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
        Button({
            val gr = g.replace(',', '.').toDoubleOrNull()
            if (gr != null && gr > 0) { log = log + (f.n to gr); st.saveFood(day, log); sel = null }
        }, Modifier.fillMaxWidth()) { Text("Добавить в дневник") }
    }

    log.forEachIndexed { i, (n, gr) ->
        FOODS.firstOrNull { it.n == n }?.let { f ->
            val x = gr / 100
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                Text("$n, ${gr.roundToInt()} г\n${(f.k * x).roundToInt()} ккал · Б ${(f.p * x).f()} · Ж ${(f.f * x).f()} · У ${(f.c * x).f()}",
                    Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                TextButton({ log = log.filterIndexed { j, _ -> j != i }; st.saveFood(day, log) }) { Text("✕") }
            }
        }
    }

    HorizontalDivider()
    Text("💧 Вода: ${water * 250} мл" + (m?.let { " из ${(it.water * 1000).roundToInt()}" } ?: ""), style = MaterialTheme.typography.titleMedium)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button({ water++; st.setWater(day, water) }) { Text("+250 мл") }
        OutlinedButton({ if (water > 0) { water--; st.setWater(day, water) } }) { Text("−") }
    }
}

@Composable
fun Tips() {
    fun block(title: String, vararg lines: String) = Pair(title, lines.toList())
    Panel("Топ белковых продуктов (на 100 г)") {
        FOODS.sortedByDescending { it.p }.take(8).forEach { Line(it.n, "${it.p.f()} г белка · ${it.k.roundToInt()} ккал") }
    }
    listOf(
        block("🥩 Как легко добрать белок",
            "Добавьте белок в каждый приём пищи: 20–40 г за раз усваивается хорошо.",
            "Творог или греческий йогурт на ночь — 200 г дают около 20–34 г белка.",
            "Консерва тунца — готовые 20+ г белка без готовки.",
            "Коктейль из 30 г сывороточного протеина — около 24 г белка; удобно после тренировки.",
            "Вместо перекуса сладким — варёные яйца, сыр, кефир."),
        block("🍚 Как добрать углеводы",
            "Основа: рис, гречка, овсянка, макароны, картофель, хлеб, фрукты.",
            "Нужно много калорий — добавьте мёд, сухофрукты, банан, сок: их легче съесть, чем крупу.",
            "Перед тренировкой берите углеводы с умеренным количеством клетчатки, после — быстрые (фрукты, рис)."),
        block("🥑 Жиры",
            "Обычно 20–35% калорий. Источники: рыба, орехи, авокадо, оливковое масло, яйца.",
            "Они очень калорийны (≈9 ккал/г): ложка масла — это около 100 ккал, учитывайте в дневнике."),
        block("📈 Набор массы",
            "Профицит 5–10% от нормы; быстрее — не значит лучше, лишнее уйдёт в жир.",
            "Жидкие калории: молоко, смузи с арахисовой пастой и бананом.",
            "Увеличивайте количество приёмов пищи, если трудно съесть много за раз."),
        block("📉 Похудение",
            "Дефицит 10–20%, темп 0.5–1% веса в неделю.",
            "Держите белок высоким, ешьте больше овощей и продуктов с клетчаткой — так сытнее.",
            "Взвешивайте еду: на глаз порции обычно занижаются."),
        block("🕐 Режим и мелочи",
            "Суммарные КБЖУ за день важнее точного времени приёмов.",
            "Клетчатка 25–35 г в день: овощи, крупы, бобовые.",
            "Вода — около 35 мл на кг веса, больше при жаре и тренировках.",
            "Продукты в приложении считаются по справочным значениям; сырой и готовый вес отличаются — выбирайте нужный вариант (сухая/варёная крупа).",
            "Это справочная информация, не замена консультации врача или диетолога.")
    ).forEach { (title, lines) ->
        Panel(title) { lines.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) } }
    }
}